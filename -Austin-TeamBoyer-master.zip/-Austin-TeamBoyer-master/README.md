# -Austin-TeamBoyer
import Foundation

print("name = Augustine Chimezie Onyema")
print("email address = augustine.onyema.pg82383@unn.edu.ng")
print("language used = swift")
print("biostack = Drug Discovery")
print("slack username = @Austin")
